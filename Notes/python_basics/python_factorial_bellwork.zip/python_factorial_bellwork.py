import math
def factorialize(number):
    result = math.factorial(number)
    print(str(result))

factorialize(5)